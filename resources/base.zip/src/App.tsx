import React, { useState } from 'react';
import { 
  ArrowUpRight, 
  Sparkles, 
  CheckCircle2, 
  ExternalLink, 
  Menu, 
  X, 
  Zap, 
  ChevronRight,
  Layers,
  Palette,
  Layout,
  MessageSquare,
  Sun,
  Moon,
  Video
} from 'lucide-react';

export default function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('Home');
  const [bgMode, setBgMode] = useState<'video' | 'pure-dark' | 'soft-dark' | 'pure-white'>('video');
  const [showDemoModal, setShowDemoModal] = useState<string | null>(null);

  // Background styling based on user preference
  const getBgClass = () => {
    switch (bgMode) {
      case 'pure-white':
        return 'bg-white text-neutral-900';
      case 'soft-dark':
        return 'bg-[#0f0f12] text-white';
      case 'pure-dark':
        return 'bg-[#050505] text-white';
      case 'video':
      default:
        return 'bg-[#0a0506] text-white';
    }
  };

  const isLight = bgMode === 'pure-white';

  return (
    <div className={`min-h-screen ${getBgClass()} transition-colors duration-300 antialiased relative flex flex-col justify-between selection:bg-[#d11a2a] selection:text-white overflow-x-hidden`}>
      
      {/* Background Infinite Loop Video from Cloudinary */}
      {bgMode === 'video' && (
        <div className="absolute inset-0 w-full h-full overflow-hidden pointer-events-none z-0">
          <video
            autoPlay
            loop
            muted
            playsInline
            className="absolute inset-0 w-full h-full object-cover scale-[1.01]"
          >
            <source src="https://res.cloudinary.com/daogle94h/video/upload/bgvideo5_yfyojo.mp4" type="video/mp4" />
            <source src="https://res.cloudinary.com/daogle94h/video/upload/bgvideo5_yfyojo.webm" type="video/webm" />
          </video>
          {/* Fallback iframe embed if direct source is blocked */}
          <iframe
            src="https://player.cloudinary.com/embed/?cloud_name=daogle94h&public_id=bgvideo5_yfyojo&autoplay=true&loop=true&muted=true&controls=false"
            className="absolute inset-0 w-full h-full border-0 pointer-events-none opacity-0"
            allow="autoplay; fullscreen"
            title="Background Video Player"
          />
          {/* Subtle dark gradient overlay to ensure text contrast */}
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/70 backdrop-blur-[1px]" />
        </div>
      )}

      {/* Subtle architectural crosshair lines */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        <div className={`absolute top-[48%] right-[32%] w-px h-[400px] ${isLight ? 'bg-neutral-200' : 'bg-white/10'}`} />
        <div className={`absolute top-[68%] right-[10%] w-[500px] h-px ${isLight ? 'bg-neutral-200' : 'bg-white/10'}`} />
        <div className={`absolute bottom-[15%] right-[35%] w-10 h-px ${isLight ? 'bg-neutral-300' : 'bg-white/10'}`} />
      </div>

      {/* Top Header / Navbar */}
      <header className="relative z-20 max-w-7xl w-full mx-auto px-6 pt-8 pb-4 flex items-center justify-between">
        
        {/* Left: JD Logo */}
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('Home')}>
          <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-[#e61932] to-[#730914] p-[1.5px] shadow-[0_0_25px_rgba(209,26,42,0.45)]">
            <div className={`w-full h-full ${isLight ? 'bg-white' : 'bg-[#0d0607]'} rounded-[10px] flex items-center justify-center`}>
              <span className="font-grotesk font-extrabold text-lg tracking-tighter bg-gradient-to-r from-[#ff2a3c] to-[#d11a2a] bg-clip-text text-transparent">
                JD
              </span>
            </div>
          </div>
          <span className={`font-grotesk font-bold tracking-tight text-lg hidden sm:inline-block ${isLight ? 'text-neutral-900' : 'text-white'}`}>
            Joyce Designs
          </span>
        </div>

        {/* Center: Navigation Links matching exact image */}
        <nav className="hidden md:flex items-center gap-8 lg:gap-10">
          {['Home', 'About', 'Portfolio', 'Services', 'Contact', 'FAQ'].map((item) => (
            <button
              key={item}
              onClick={() => {
                setActiveTab(item);
                if (item !== 'Home') setShowDemoModal(item);
              }}
              className={`text-sm font-medium tracking-wide transition-all ${
                activeTab === item
                  ? isLight
                    ? 'text-[#d11a2a] font-semibold'
                    : 'text-white font-semibold drop-shadow-[0_0_12px_rgba(255,255,255,0.4)]'
                  : isLight
                    ? 'text-neutral-500 hover:text-neutral-900'
                    : 'text-neutral-300 hover:text-white'
              }`}
            >
              {item}
            </button>
          ))}
        </nav>

        {/* Right CTA Button & Mobile Menu Toggle */}
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setShowDemoModal('Get In Touch')}
            className="bg-gradient-to-r from-[#d11a2a] to-[#a31220] hover:from-[#e61932] hover:to-[#b31225] active:scale-95 text-white font-medium px-6 py-2.5 rounded-xl text-sm tracking-wide shadow-[0_4px_24px_rgba(209,26,42,0.5)] hover:shadow-[0_6px_28px_rgba(209,26,42,0.7)] border border-red-500/30 transition-all duration-200 cursor-pointer"
          >
            Get In Touch
          </button>

          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className={`md:hidden p-2 rounded-lg ${isLight ? 'text-neutral-800 hover:bg-neutral-100' : 'text-neutral-300 hover:bg-neutral-800'}`}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </header>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className={`md:hidden relative z-30 px-6 py-4 ${isLight ? 'bg-white border-b border-neutral-200' : 'bg-[#0f0709] border-b border-red-950/40'} animate-in fade-in slide-in-from-top duration-200`}>
          <div className="flex flex-col gap-4 py-2">
            {['Home', 'About', 'Portfolio', 'Services', 'Contact', 'FAQ'].map((item) => (
              <button
                key={item}
                onClick={() => {
                  setActiveTab(item);
                  setMobileMenuOpen(false);
                  if (item !== 'Home') setShowDemoModal(item);
                }}
                className={`text-left text-base font-medium py-1.5 ${
                  activeTab === item ? 'text-[#d11a2a]' : isLight ? 'text-neutral-600' : 'text-neutral-300'
                }`}
              >
                {item}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Main Hero Section matching exact reference photo without right image */}
      <main className="relative z-10 max-w-7xl w-full mx-auto px-6 my-auto pt-8 pb-16 lg:py-16 flex flex-col justify-center">
        
        {/* Left Hero Content */}
        <div className="flex flex-col items-start pt-4 sm:pt-0 max-w-4xl">
          
          {/* Badge: [NEW] Your Design Solution */}
          <div className={`inline-flex items-center gap-3 ${isLight ? 'bg-neutral-100 border-neutral-200 text-neutral-800' : 'bg-black/60 border-red-900/40 text-neutral-200'} border p-1 sm:p-1.5 pr-4 rounded-full mb-8 backdrop-blur-md transition-transform hover:scale-[1.01] cursor-default shadow-sm`}>
            <span className="bg-gradient-to-r from-[#e61932] to-[#b31225] text-white font-extrabold text-[10px] sm:text-[11px] px-2.5 py-0.5 rounded-md uppercase tracking-wider shadow-sm">
              NEW
            </span>
            <span className="text-xs sm:text-sm font-normal tracking-wide">
              Your Design Solution
            </span>
          </div>

          {/* Heading: Exact Text & Line Breaks */}
          <h1 className={`text-4xl sm:text-6xl md:text-7xl lg:text-[78px] xl:text-[84px] font-grotesk font-semibold tracking-[-0.03em] leading-[1.06] mb-8 ${isLight ? 'text-neutral-950' : 'text-white'}`}>
            Brands Are Stories.
            <br />
            Design Is How We Tell
            <br />
            Them.
          </h1>

          {/* Paragraph text exact match */}
          <p className={`text-sm sm:text-base md:text-lg max-w-lg font-normal leading-relaxed mb-10 ${isLight ? 'text-neutral-600' : 'text-neutral-300'}`}>
            At Joyce Designs, we turn ideas into experiences – building brands
            that are seen, felt, and remembered.
          </p>

          {/* CTA Buttons: See All Projects | Book a call */}
          <div className="flex flex-wrap items-center gap-4 sm:gap-5 w-full sm:w-auto">
            <button 
              onClick={() => setShowDemoModal('Portfolio')}
              className="bg-gradient-to-r from-[#d11a2a] via-[#e61932] to-[#b31225] hover:from-[#e61932] hover:to-[#c4152a] active:scale-[0.98] text-white font-semibold px-8 py-4 rounded-xl text-sm sm:text-base tracking-wide shadow-[0_8px_30px_rgba(209,26,42,0.45)] hover:shadow-[0_12px_36px_rgba(209,26,42,0.65)] border border-red-400/30 transition-all duration-200 cursor-pointer w-full sm:w-auto text-center flex items-center justify-center gap-2 group"
            >
              See All Projects
              <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>

            <button 
              onClick={() => setShowDemoModal('Book a call')}
              className={`${
                isLight 
                  ? 'bg-neutral-100 hover:bg-neutral-200 border-neutral-300 text-neutral-900' 
                  : 'bg-black/50 hover:bg-red-950/40 border-red-900/40 text-neutral-100 backdrop-blur-md'
              } border font-medium px-8 py-4 rounded-xl text-sm sm:text-base tracking-wide transition-all duration-200 cursor-pointer w-full sm:w-auto text-center flex items-center justify-center gap-2`}
            >
              Book a call
            </button>
          </div>

        </div>

      </main>

      {/* Bottom bar & Controls */}
      <footer className="relative z-20 max-w-7xl w-full mx-auto px-6 py-6 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-red-950/30">
        
        {/* Background Mode Selector */}
        <div className="flex flex-wrap items-center gap-2 bg-black/60 border border-red-950/50 px-3 py-1.5 rounded-xl backdrop-blur text-xs text-neutral-400">
          <span className="font-medium text-neutral-300 mr-1">Background:</span>
          <button 
            onClick={() => setBgMode('video')}
            className={`px-2.5 py-1 rounded-lg transition-all flex items-center gap-1.5 ${bgMode === 'video' ? 'bg-[#d11a2a] text-white font-bold shadow-sm' : 'hover:text-white'}`}
          >
            <Video className="w-3.5 h-3.5" />
            Loop Video
          </button>
          <button 
            onClick={() => setBgMode('pure-dark')}
            className={`px-2.5 py-1 rounded-lg transition-all ${bgMode === 'pure-dark' ? 'bg-[#d11a2a] text-white font-bold' : 'hover:text-white'}`}
          >
            Pitch Black
          </button>
          <button 
            onClick={() => setBgMode('soft-dark')}
            className={`px-2.5 py-1 rounded-lg transition-all ${bgMode === 'soft-dark' ? 'bg-[#d11a2a] text-white font-bold' : 'hover:text-white'}`}
          >
            Dark Slate
          </button>
          <button 
            onClick={() => setBgMode('pure-white')}
            className={`px-2.5 py-1 rounded-lg transition-all ${bgMode === 'pure-white' ? 'bg-[#d11a2a] text-white font-bold' : 'hover:text-white'}`}
          >
            Clean White
          </button>
        </div>

      </footer>

      {/* Interactive Modal for testing CTA buttons & navigation items */}
      {showDemoModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className={`relative w-full max-w-lg ${isLight ? 'bg-white text-neutral-900' : 'bg-[#120a0c] text-white border border-red-900/40'} p-6 sm:p-8 rounded-2xl shadow-2xl`}>
            
            <div className="flex items-center justify-between pb-4 mb-4 border-b border-red-950/50">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[#e61932]" />
                <h3 className="font-grotesk font-bold text-xl">{showDemoModal}</h3>
              </div>
              <button 
                onClick={() => setShowDemoModal(null)}
                className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-red-950/50"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className={`text-sm leading-relaxed mb-6 ${isLight ? 'text-neutral-600' : 'text-neutral-300'}`}>
              You clicked on <strong className="text-[#e61932]">{showDemoModal}</strong>. 
              The hero landing page structure replicates Joyce Designs exactly as requested.
            </p>

            {showDemoModal === 'Book a call' || showDemoModal === 'Get In Touch' ? (
              <div className="space-y-4">
                <input 
                  type="text" 
                  placeholder="Your Name" 
                  className={`w-full px-4 py-3 rounded-xl text-sm ${isLight ? 'bg-neutral-100 border-neutral-300' : 'bg-black/60 border-red-900/40 text-white'} border focus:outline-none focus:border-[#e61932]`}
                />
                <input 
                  type="email" 
                  placeholder="name@company.com" 
                  className={`w-full px-4 py-3 rounded-xl text-sm ${isLight ? 'bg-neutral-100 border-neutral-300' : 'bg-black/60 border-red-900/40 text-white'} border focus:outline-none focus:border-[#e61932]`}
                />
                <button 
                  onClick={() => setShowDemoModal(null)}
                  className="w-full py-3.5 bg-gradient-to-r from-[#d11a2a] to-[#b31225] hover:from-[#e61932] hover:to-[#c4152a] text-white font-semibold rounded-xl text-sm transition-all shadow-lg shadow-red-900/30"
                >
                  Send Inquiry to Joyce Designs
                </button>
              </div>
            ) : (
              <div className="flex justify-end">
                <button 
                  onClick={() => setShowDemoModal(null)}
                  className="px-6 py-2.5 bg-[#d11a2a] text-white font-medium rounded-xl text-sm"
                >
                  Back to Landing Page
                </button>
              </div>
            )}

          </div>
        </div>
      )}

    </div>
  );
}


